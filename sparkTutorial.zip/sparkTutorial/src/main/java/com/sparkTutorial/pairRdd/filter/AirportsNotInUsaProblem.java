package com.sparkTutorial.pairRdd.filter;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;

import scala.Tuple2;

public class AirportsNotInUsaProblem {

    public static void main(String[] args) throws Exception {

        /* Create a Spark program to read the airport data from in/airports.text;
           generate a pair RDD with airport name being the key and country name being the value.
           
           Then remove all the airports which are located in United States and output the pair RDD 
           to out/airports_not_in_usa_pair_rdd.text

           Each row of the input file contains the following columns:
           Airport ID, Name of airport, Main city served by airport, Country where airport is located,
           IATA/FAA code, ICAO Code, Latitude, Longitude, Altitude, Timezone, DST, Timezone in Olson format

           Sample output:

           ("Kamloops", "Canada")
           ("Wewak Intl", "Papua New Guinea")
           ...
         */
    SparkConf conf = new SparkConf().setAppName("Airportpairfilter").setMaster("local[*]");
    JavaSparkContext sc = new JavaSparkContext(conf);
    
    JavaRDD<String> FirstRDD= sc.textFile("in/airports.text");
    JavaPairRDD<String, String> pair1RDD = FirstRDD.mapToPair(getPairFunction());}
    
     
        
    private static PairFunction<String, String, String> getPairFunction() {
        return airpair1 -> new Tuple2<>(airpair1.split(" ")[1], String.valueOf(airpair1.split(" ")[3]));
                 
        
     JavaRDD<String> removeRDD = pair1RDD.filter(countryname -> countrynamenot.equals("United States")
    
    
    /*JavaPairRDD<String, Integer> pairRDD = regularRDDs.mapToPair(getPairFunction());

        pairRDD.coalesce(1).saveAsTextFile("out/pair_rdd_from_regular_rdd");
    }

    private static PairFunction<String, String, Integer> getPairFunction() {
        return s -> new Tuple2<>(s.split(" ")[0], Integer.valueOf(s.split(" ")[1]));*/

    
    
    
    }
}
